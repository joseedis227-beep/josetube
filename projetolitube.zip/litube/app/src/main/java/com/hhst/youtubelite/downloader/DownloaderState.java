package com.hhst.youtubelite.downloader;

public enum DownloaderState {
  RUNNING,
  CANCELLED,
  STOPPED,
  FINISHED,
  Merging,
  DOWNLOADING
}
